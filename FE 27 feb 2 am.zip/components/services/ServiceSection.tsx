"use client";

export default function ServicesIndex({
  items,
}: {
  items: Array<{ id: string; title: string }>;
}) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-4 md:p-6">
      <div className="flex flex-col gap-3 md:flex-row md:flex-wrap">
        {items.map((it) => (
          <a
            key={it.id}
            href={`#${it.id}`}
            className="rounded-2xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-white/80 hover:bg-white/5 hover:text-white"
          >
            {it.title}
          </a>
        ))}
      </div>
    </div>
  );
}