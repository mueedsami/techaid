import { ClientItem } from "@/lib/api";

function typeBadgeStyle(type: ClientItem["type"]) {
  switch (type) {
    case "University":
      return "border-blue-400/20 bg-blue-400/10 text-blue-200";
    case "Industry":
      return "border-emerald-400/20 bg-emerald-400/10 text-emerald-200";
    case "Government":
      return "border-amber-400/20 bg-amber-400/10 text-amber-200";
    case "Institute":
      return "border-fuchsia-400/20 bg-fuchsia-400/10 text-fuchsia-200";
    case "Research":
      return "border-cyan-400/20 bg-cyan-400/10 text-cyan-200";
    default:
      return "border-white/15 bg-white/10 text-white/80";
  }
}

export default function ClientsGrid({
  title = "Trusted by Institutions and Industry",
  subtitle = "We work with universities, institutes, industries, and organizations across Bangladesh through dependable technical support and engineering solutions.",
  items,
}: {
  title?: string;
  subtitle?: string;
  items: ClientItem[];
}) {
  return (
    <section className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">{title}</h2>
        <p className="mt-2 max-w-3xl text-sm text-white/65 md:text-base">{subtitle}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((client) => (
          <article
            key={client.id}
            className="group rounded-2xl border border-white/10 bg-gradient-to-b from-white/5 to-transparent p-4 transition hover:border-white/20 hover:bg-white/[0.07]"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm text-white/50">Client</p>
                <h3 className="mt-1 text-base font-semibold leading-5 text-white/95">
                  {client.name}
                </h3>
              </div>

              <span
                className={`shrink-0 rounded-full border px-2 py-0.5 text-[11px] ${typeBadgeStyle(
                  client.type
                )}`}
              >
                {client.type}
              </span>
            </div>

            <div className="mt-4 rounded-xl border border-white/10 bg-black/20 px-3 py-2">
              <p className="text-xs text-white/50">Sector</p>
              <p className="mt-1 text-sm text-white/85">{client.sector || "Engineering"}</p>
            </div>

            <p className="mt-4 text-sm leading-6 text-white/70">
              {client.summary || "Technical support and engineering service provided."}
            </p>
          </article>
        ))}
      </div>
    </section>
  );
}