import { TestimonialItem } from "@/lib/api";

export default function TestimonialsSection({
  title = "What Clients Say",
  subtitle = "A few words from organizations we have supported with sourcing, technical solutions, and implementation.",
  items,
  compact = false,
}: {
  title?: string;
  subtitle?: string;
  items: TestimonialItem[];
  compact?: boolean;
}) {
  return (
    <section className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6 md:p-8">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">{title}</h2>
        <p className="mt-2 max-w-3xl text-sm text-white/65 md:text-base">{subtitle}</p>
      </div>

      <div className={`grid gap-4 ${compact ? "md:grid-cols-2" : "lg:grid-cols-3"}`}>
        {items.map((t) => {
          const rating = Math.max(1, Math.min(5, Number(t.rating || 5)));
          return (
            <article
              key={t.id}
              className="rounded-2xl border border-white/10 bg-black/20 p-4 md:p-5"
            >
              <div className="mb-3 flex items-center gap-1 text-yellow-300/90">
                {Array.from({ length: rating }).map((_, i) => (
                  <span key={i}>★</span>
                ))}
              </div>

              <p className="text-sm leading-6 text-white/80">“{t.quote}”</p>

              <div className="mt-4 border-t border-white/10 pt-3">
                <p className="text-sm font-medium text-white/95">{t.name}</p>
                <p className="text-xs text-white/55">
                  {[t.role, t.company].filter(Boolean).join(" · ")}
                </p>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}