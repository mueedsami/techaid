"use client";

import Link from "next/link";
import { ReactNode } from "react";

type AdminTab =
  | "inquiries"
  | "clients"
  | "testimonials"
  | "product-categories"
  | "products";

export default function AdminShell({
  title,
  subtitle = "Admin Content",
  activeTab,
  children,
}: {
  title: string;
  subtitle?: string;
  activeTab: AdminTab;
  children: ReactNode;
}) {
  return (
    <main className="min-h-screen bg-black text-white">
      <div className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-6 rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm text-white/60">{subtitle}</p>
              <h1 className="mt-1 text-2xl font-semibold">{title}</h1>
            </div>

            <div className="flex flex-wrap gap-2">
              <NavBtn
                href="/admin/inquiries"
                label="Inquiries"
                active={activeTab === "inquiries"}
              />
              <NavBtn
                href="/admin/clients"
                label="Clients"
                active={activeTab === "clients"}
              />
              <NavBtn
                href="/admin/testimonials"
                label="Testimonials"
                active={activeTab === "testimonials"}
              />

              <NavBtn
  href="/admin/product-categories"
  label="Product Categories"
  active={activeTab === "product-categories"}
/>
<NavBtn
  href="/admin/products"
  label="Products"
  active={activeTab === "products"}
/>

              <button
                onClick={async () => {
                  await fetch("/api/admin/auth", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "logout" }),
                  });
                  window.location.href = "/admin/login";
                }}
                className="rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm hover:bg-white/10"
              >
                Logout
              </button>
            </div>
          </div>
        </div>

        {children}
      </div>
    </main>
  );
}

function NavBtn({
  href,
  label,
  active,
}: {
  href: string;
  label: string;
  active?: boolean;
}) {
  return (
    <Link
      href={href}
      className={
        active
          ? "rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-sm"
          : "rounded-xl border border-white/10 bg-black/30 px-3 py-2 text-sm hover:bg-white/10"
      }
    >
      {label}
    </Link>
  );
}