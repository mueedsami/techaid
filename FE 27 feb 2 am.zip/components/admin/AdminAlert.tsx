export default function AdminAlert({
  type,
  text,
}: {
  type: "success" | "error";
  text: string;
}) {
  return (
    <div
      className={`mb-4 rounded-xl border px-4 py-3 text-sm ${
        type === "success"
          ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-200"
          : "border-rose-400/20 bg-rose-400/10 text-rose-200"
      }`}
    >
      {text}
    </div>
  );
}