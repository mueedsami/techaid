import { ReactNode } from "react";

export default function AdminSectionCard({
  title,
  children,
}: {
  title?: string;
  children: ReactNode;
}) {
  return (
    <section className="mb-4 rounded-3xl border border-white/10 bg-white/5 p-4 md:p-5">
      {title && <h2 className="mb-3 text-sm font-semibold text-white/90">{title}</h2>}
      {children}
    </section>
  );
}