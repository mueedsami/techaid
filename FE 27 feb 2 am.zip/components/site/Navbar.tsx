// "use client";

// import Link from "next/link";
// import { usePathname } from "next/navigation";
// import { useEffect, useRef, useState } from "react";

// const services = [
//   { label: "Global Sourcing", hash: "global-sourcing" },
//   { label: "Supply & Installation", hash: "supply-installation" },
//   { label: "Repairing & Servicing", hash: "repairing-servicing" },
//   { label: "Training", hash: "training" },
//   { label: "Design & Implementation", hash: "design-implementation" },
// ];

// function cx(...classes: Array<string | false | undefined>) {
//   return classes.filter(Boolean).join(" ");
// }

// export default function Navbar() {
//   const pathname = usePathname();
//   const [open, setOpen] = useState(false);
//   const wrapperRef = useRef<HTMLDivElement | null>(null);

//   // close dropdown on outside click
//   useEffect(() => {
//     const onDown = (e: MouseEvent) => {
//       if (!wrapperRef.current) return;
//       if (!wrapperRef.current.contains(e.target as Node)) setOpen(false);
//     };
//     window.addEventListener("mousedown", onDown);
//     return () => window.removeEventListener("mousedown", onDown);
//   }, []);

//   const navLink = (href: string, label: string) => {
//     const active = pathname === href;
//     return (
//       <Link
//         href={href}
//         className={cx(
//           "text-sm font-medium transition-colors",
//           active ? "text-white" : "text-white/70 hover:text-white"
//         )}
//       >
//         {label}
//       </Link>
//     );
//   };

//   return (
//     <header className="sticky top-0 z-50 border-b border-white/10 bg-black/70 backdrop-blur">
//       <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
//         <Link href="/" className="text-base font-semibold tracking-wide text-white">
//           Technical Aid
//         </Link>

//         <nav className="hidden items-center gap-6 md:flex">
//           {navLink("/", "Home")}

//           {/* Services dropdown */}
//           <div className="relative" ref={wrapperRef}>
//             <button
//               type="button"
//               onClick={() => setOpen((v) => !v)}
//               className="text-sm font-medium text-white/70 transition-colors hover:text-white"
//               aria-haspopup="menu"
//               aria-expanded={open}
//             >
//               Services <span className="ml-1 text-white/50">▾</span>
//             </button>

//             {open && (
//               <div
//                 role="menu"
//                 className="absolute left-0 mt-3 w-64 overflow-hidden rounded-2xl border border-white/10 bg-zinc-950 shadow-2xl"
//               >
//                 <div className="p-2">
//                   {services.map((s) => (
//                     <Link
//                       key={s.hash}
//                       href={`/services#${s.hash}`}
//                       onClick={() => setOpen(false)}
//                       className="block rounded-xl px-3 py-2 text-sm text-white/80 hover:bg-white/5 hover:text-white"
//                       role="menuitem"
//                     >
//                       {s.label}
//                     </Link>
//                   ))}
//                 </div>
//               </div>
//             )}
//           </div>

//           {navLink("/products", "Products")}
//           {navLink("/about", "About Us")}
//           {navLink("/contact", "Contact Us")}
//           {navLink("/clients", "Our Clients")}
//         </nav>

//         {/* Mobile: keep simple for now */}
//         <div className="flex items-center gap-2">
//   <Link
//     href="/contact"
//     className="hidden rounded-xl border border-white/10 bg-black/30 px-3 py-1.5 text-sm font-medium text-white/85 hover:bg-white/10 md:inline-flex"
//   >
//     Contact
//   </Link>
//   <Link
//     href="/contact"
//     className="rounded-xl border border-white/15 bg-white/10 px-3.5 py-1.5 text-sm font-medium text-white hover:bg-white/15"
//   >
//     Get a Quote
//   </Link>
// </div>
//       </div>
//     </header>
//   );
// }



"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { getProductCategoryTree, PublicProductCategoryTreeItem } from "@/lib/api";

const services = [
  { label: "Global Sourcing", hash: "global-sourcing" },
  { label: "Supply & Installation", hash: "supply-installation" },
  { label: "Repairing & Servicing", hash: "repairing-servicing" },
  { label: "Training", hash: "training" },
  { label: "Design & Implementation", hash: "design-implementation" },
];

function cx(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export default function Navbar() {
  const pathname = usePathname();

  const [servicesOpen, setServicesOpen] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);

  const [mobileOpen, setMobileOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const [mobileProductsOpen, setMobileProductsOpen] = useState(false);

  const [productCats, setProductCats] = useState<PublicProductCategoryTreeItem[]>([]);
  const [catsLoading, setCatsLoading] = useState(false);

  const [activeMegaParent, setActiveMegaParent] = useState<number | null>(null);

  const servicesRef = useRef<HTMLDivElement | null>(null);
  const productsRef = useRef<HTMLDivElement | null>(null);
  const mobileRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let mounted = true;
    setCatsLoading(true);
    getProductCategoryTree()
      .then((items) => {
        if (!mounted) return;
        setProductCats(items || []);
        if (items?.length) setActiveMegaParent(items[0].id);
      })
      .catch(() => {
        if (!mounted) return;
        setProductCats([]);
      })
      .finally(() => {
        if (!mounted) return;
        setCatsLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      if (servicesRef.current && !servicesRef.current.contains(t)) setServicesOpen(false);
      if (productsRef.current && !productsRef.current.contains(t)) setProductsOpen(false);
      if (mobileRef.current && !mobileRef.current.contains(t)) {
        setMobileOpen(false);
        setMobileProductsOpen(false);
        setMobileServicesOpen(false);
      }
    };

    window.addEventListener("mousedown", onDown);
    return () => window.removeEventListener("mousedown", onDown);
  }, []);

  useEffect(() => {
    // close dropdowns on route change
    setServicesOpen(false);
    setProductsOpen(false);
    setMobileOpen(false);
    setMobileProductsOpen(false);
    setMobileServicesOpen(false);
  }, [pathname]);

  const navLink = (href: string, label: string) => {
    const active = pathname === href;
    return (
      <Link
        href={href}
        className={cx(
          "text-sm font-medium transition-colors",
          active ? "text-white" : "text-white/70 hover:text-white"
        )}
      >
        {label}
      </Link>
    );
  };

  const activeParent =
    productCats.find((p) => p.id === activeMegaParent) || productCats[0] || null;

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/70 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-base font-semibold tracking-wide text-white">
          Technical Aid
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-6 md:flex">
          {navLink("/", "Home")}

          {/* Services dropdown */}
          <div className="relative" ref={servicesRef}>
            <button
              type="button"
              onClick={() => {
                setServicesOpen((v) => !v);
                setProductsOpen(false);
              }}
              className="text-sm font-medium text-white/70 transition-colors hover:text-white"
              aria-haspopup="menu"
              aria-expanded={servicesOpen}
            >
              Services <span className="ml-1 text-white/50">▾</span>
            </button>

            {servicesOpen && (
              <div
                role="menu"
                className="absolute left-0 mt-3 w-64 overflow-hidden rounded-2xl border border-white/10 bg-zinc-950 shadow-2xl"
              >
                <div className="p-2">
                  {services.map((s) => (
                    <Link
                      key={s.hash}
                      href={`/services#${s.hash}`}
                      onClick={() => setServicesOpen(false)}
                      className="block rounded-xl px-3 py-2 text-sm text-white/80 hover:bg-white/5 hover:text-white"
                      role="menuitem"
                    >
                      {s.label}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Products mega dropdown */}
          <div
            className="relative"
            ref={productsRef}
            onMouseLeave={() => setProductsOpen(false)}
          >
            <button
              type="button"
              onClick={() => {
                setProductsOpen((v) => !v);
                setServicesOpen(false);
              }}
              onMouseEnter={() => setProductsOpen(true)}
              className={cx(
                "text-sm font-medium transition-colors",
                pathname.startsWith("/products")
                  ? "text-white"
                  : "text-white/70 hover:text-white"
              )}
              aria-haspopup="menu"
              aria-expanded={productsOpen}
            >
              Products <span className="ml-1 text-white/50">▾</span>
            </button>

            {productsOpen && (
              <div className="absolute left-1/2 z-50 mt-3 w-[720px] -translate-x-1/2 overflow-hidden rounded-2xl border border-white/10 bg-zinc-950 shadow-2xl">
                <div className="grid grid-cols-[250px_1fr]">
                  {/* Parents column */}
                  <div className="border-r border-white/10 bg-white/[0.02] p-2">
                    <Link
                      href="/products"
                      onClick={() => setProductsOpen(false)}
                      className="mb-2 block rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm font-medium text-white hover:bg-white/10"
                    >
                      View All Products
                    </Link>

                    {catsLoading ? (
                      <div className="px-3 py-2 text-sm text-white/50">Loading...</div>
                    ) : productCats.length === 0 ? (
                      <div className="px-3 py-2 text-sm text-white/50">
                        Categories unavailable
                      </div>
                    ) : (
                      productCats.map((cat) => (
                        <button
                          key={cat.id}
                          type="button"
                          onMouseEnter={() => setActiveMegaParent(cat.id)}
                          onClick={() => setActiveMegaParent(cat.id)}
                          className={cx(
                            "mb-1 block w-full rounded-xl px-3 py-2 text-left text-sm transition",
                            activeMegaParent === cat.id
                              ? "bg-white/10 text-white"
                              : "text-white/70 hover:bg-white/5 hover:text-white"
                          )}
                        >
                          {cat.name}
                        </button>
                      ))
                    )}
                  </div>

                  {/* Children column */}
                  <div className="p-4">
                    {!activeParent ? (
                      <div className="text-sm text-white/50">No categories found.</div>
                    ) : (
                      <>
                        <div className="mb-3 flex items-center justify-between">
                          <h3 className="text-sm font-semibold text-white">
                            {activeParent.name}
                          </h3>
                          <Link
                            href={`/products?category=${activeParent.slug}`}
                            onClick={() => setProductsOpen(false)}
                            className="text-xs text-white/60 hover:text-white"
                          >
                            View all →
                          </Link>
                        </div>

                        {activeParent.children?.length ? (
                          <div className="grid grid-cols-2 gap-2">
                            {activeParent.children.map((sub) => (
                              <Link
                                key={sub.id}
                                href={`/products?category=${sub.slug}`}
                                onClick={() => setProductsOpen(false)}
                                className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-white/80 hover:bg-white/5 hover:text-white"
                              >
                                {sub.name}
                              </Link>
                            ))}
                          </div>
                        ) : (
                          <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3 text-sm text-white/60">
                            No subcategories yet.
                            <div className="mt-2">
                              <Link
                                href={`/products?category=${activeParent.slug}`}
                                onClick={() => setProductsOpen(false)}
                                className="text-white/80 hover:text-white"
                              >
                                Browse {activeParent.name}
                              </Link>
                            </div>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {navLink("/about", "About Us")}
          {navLink("/contact", "Contact Us")}
          {navLink("/clients", "Our Clients")}
        </nav>

        {/* Mobile top actions */}
        <div className="flex items-center gap-2 md:hidden" ref={mobileRef}>
          <Link
            href="/contact"
            className="rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-sm font-medium text-white hover:bg-white/10"
          >
            Contact
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            className="rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-sm font-medium text-white"
            aria-expanded={mobileOpen}
            aria-label="Toggle menu"
          >
            ☰
          </button>

          {mobileOpen && (
            <div className="absolute right-4 top-[62px] z-50 w-[92vw] max-w-sm overflow-hidden rounded-2xl border border-white/10 bg-zinc-950 shadow-2xl">
              <div className="p-2">
                <MobileLink href="/" label="Home" onClick={() => setMobileOpen(false)} />

                {/* Mobile Services */}
                <button
                  type="button"
                  onClick={() => setMobileServicesOpen((v) => !v)}
                  className="mt-1 flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm text-white/85 hover:bg-white/5"
                >
                  <span>Services</span>
                  <span className="text-white/50">{mobileServicesOpen ? "▴" : "▾"}</span>
                </button>
                {mobileServicesOpen && (
                  <div className="mt-1 space-y-1 rounded-xl border border-white/10 bg-white/[0.02] p-2">
                    {services.map((s) => (
                      <Link
                        key={s.hash}
                        href={`/services#${s.hash}`}
                        onClick={() => {
                          setMobileOpen(false);
                          setMobileServicesOpen(false);
                        }}
                        className="block rounded-lg px-2 py-1.5 text-sm text-white/70 hover:bg-white/5 hover:text-white"
                      >
                        {s.label}
                      </Link>
                    ))}
                  </div>
                )}

                {/* Mobile Products */}
                <button
                  type="button"
                  onClick={() => setMobileProductsOpen((v) => !v)}
                  className="mt-1 flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm text-white/85 hover:bg-white/5"
                >
                  <span>Products</span>
                  <span className="text-white/50">{mobileProductsOpen ? "▴" : "▾"}</span>
                </button>

                {mobileProductsOpen && (
                  <div className="mt-1 rounded-xl border border-white/10 bg-white/[0.02] p-2">
                    <Link
                      href="/products"
                      onClick={() => {
                        setMobileOpen(false);
                        setMobileProductsOpen(false);
                      }}
                      className="mb-2 block rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-sm text-white"
                    >
                      View All Products
                    </Link>

                    {catsLoading ? (
                      <div className="px-2 py-1 text-sm text-white/50">Loading...</div>
                    ) : productCats.length === 0 ? (
                      <div className="px-2 py-1 text-sm text-white/50">
                        Categories unavailable
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {productCats.map((cat) => (
                          <div key={cat.id} className="rounded-lg border border-white/10 p-2">
                            <Link
                              href={`/products?category=${cat.slug}`}
                              onClick={() => setMobileOpen(false)}
                              className="block text-sm font-medium text-white/90"
                            >
                              {cat.name}
                            </Link>

                            {cat.children?.length ? (
                              <div className="mt-1 space-y-1">
                                {cat.children.map((sub) => (
                                  <Link
                                    key={sub.id}
                                    href={`/products?category=${sub.slug}`}
                                    onClick={() => setMobileOpen(false)}
                                    className="block rounded px-2 py-1 text-xs text-white/65 hover:bg-white/5 hover:text-white"
                                  >
                                    └─ {sub.name}
                                  </Link>
                                ))}
                              </div>
                            ) : null}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <MobileLink href="/about" label="About Us" onClick={() => setMobileOpen(false)} />
                <MobileLink
                  href="/contact"
                  label="Contact Us"
                  onClick={() => setMobileOpen(false)}
                />
                <MobileLink
                  href="/clients"
                  label="Our Clients"
                  onClick={() => setMobileOpen(false)}
                />
              </div>
            </div>
          )}
        </div>

        {/* Desktop CTA */}
        <Link
          href="/contact"
          className="hidden rounded-xl border border-white/15 bg-white/5 px-3 py-1.5 text-sm font-medium text-white hover:bg-white/10 md:inline-flex"
        >
          Get in touch
        </Link>
      </div>
    </header>
  );
}

function MobileLink({
  href,
  label,
  onClick,
}: {
  href: string;
  label: string;
  onClick?: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onClick}
      className="mt-1 block rounded-xl px-3 py-2 text-sm text-white/85 hover:bg-white/5"
    >
      {label}
    </Link>
  );
}