"use client";

import { FormEvent, useMemo, useState } from "react";
import { submitContactForm } from "@/lib/api";

type FormState = {
  name: string;
  email: string;
  company: string;
  phone: string;
  service: string;
  message: string;
};

const initialForm: FormState = {
  name: "",
  email: "",
  company: "",
  phone: "",
  service: "",
  message: "",
};

const serviceOptions = [
  "Global Sourcing",
  "Supply & Installation",
  "Repairing & Servicing",
  "Training",
  "Design & Implementation",
];

export default function ContactPage() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string[]>>({});

  const mapUrl = useMemo(() => {
    const query = encodeURIComponent(
      "House No 64, Road 6, Block A, Section 12, Mirpur 1216, Dhaka, Bangladesh"
    );
    return `https://www.google.com/maps/search/?api=1&query=${query}`;
  }, []);

  const onChange = (key: keyof FormState, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrorMsg("");
    setSuccessMsg("");
    setFieldErrors((prev) => ({ ...prev, [key]: [] }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSuccessMsg("");
    setErrorMsg("");
    setFieldErrors({});

    try {
      const res = await submitContactForm(form);

      if (res.ok) {
        setSuccessMsg(res.message || "Your message has been sent successfully.");
        setForm(initialForm);
      } else {
        setErrorMsg("Failed to submit form. Please try again.");
      }
    } catch (err: any) {
      if (err?.status === 422 && err?.errors) {
        setFieldErrors(err.errors);
        setErrorMsg("Please fix the highlighted fields.");
      } else {
        setErrorMsg("Something went wrong. Please try again.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const fieldError = (name: keyof FormState) => fieldErrors[name]?.[0];

  return (
    <main className="relative overflow-hidden">
      {/* Ambient background glow */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-64 w-64 rounded-full bg-white/5 blur-3xl" />
      </div>

      <div className="mx-auto max-w-6xl px-4 py-12 md:py-16">
        {/* HERO */}
        <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6 md:p-10">
          <div className="absolute right-0 top-0 hidden h-40 w-40 translate-x-10 -translate-y-10 rounded-full border border-white/10 md:block" />
          <div className="absolute bottom-0 left-0 hidden h-24 w-24 -translate-x-8 translate-y-8 rounded-full border border-white/10 md:block" />

          <p className="text-sm text-white/60">Contact Us</p>
          <h1 className="mt-2 max-w-4xl text-3xl font-semibold tracking-tight md:text-5xl">
            Let’s build your next engineering solution with confidence.
          </h1>
          <p className="mt-4 max-w-3xl text-white/70">
            Whether you need sourcing, installation, servicing, training, or a complete technical implementation,
            our team is ready to support you with reliable, standards-compliant, and cost-effective solutions.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <a
              href="tel:01518357567"
              className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/15"
            >
              Call Now
            </a>
            <a
              href="mailto:info@technicalaidbd.com"
              className="rounded-xl border border-white/15 bg-black/30 px-4 py-2 text-sm font-medium hover:bg-white/10"
            >
              Email Us
            </a>
          </div>
        </section>

        {/* MAIN GRID */}
        <section className="mt-10 grid gap-6 lg:grid-cols-12">
          {/* LEFT COLUMN */}
          <div className="space-y-6 lg:col-span-4">
            {/* Contact details */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <h2 className="text-lg font-semibold">Contact Information</h2>
              <p className="mt-2 text-sm text-white/60">
                Reach us directly for project discussions, quotations, and technical consultations.
              </p>

              <div className="mt-5 space-y-4">
                <InfoCard label="Phone" value="01518357567" href="tel:01518357567" />
                <InfoCard
                  label="Email"
                  value="info@technicalaidbd.com"
                  href="mailto:info@technicalaidbd.com"
                />
                <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                  <p className="text-xs text-white/50">Address</p>
                  <p className="mt-1 text-sm leading-6 text-white/85">
                    House No:- 64, Road: 6, Block A, Section 12, Mirpur 1216, Dhaka, Bangladesh
                  </p>
                  <a
                    href={mapUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex rounded-lg border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-medium hover:bg-white/15"
                  >
                    Open in Maps
                  </a>
                </div>
              </div>
            </div>

            {/* Service lines */}
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <h3 className="text-base font-semibold">Service Lines</h3>
              <p className="mt-2 text-sm text-white/60">
                Select a service in the form, or contact us directly for a custom requirement.
              </p>
              <ul className="mt-4 space-y-2">
                {serviceOptions.map((s) => (
                  <li
                    key={s}
                    className="rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm text-white/80"
                  >
                    {s}
                  </li>
                ))}
              </ul>
            </div>

            {/* Trust panel */}
            <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6">
              <h3 className="text-base font-semibold">Why clients reach out to us</h3>
              <ul className="mt-4 space-y-3 text-sm text-white/75">
                <li className="rounded-xl border border-white/10 bg-black/20 p-3">
                  Fast technical understanding of your requirement
                </li>
                <li className="rounded-xl border border-white/10 bg-black/20 p-3">
                  Practical, cost-effective engineering recommendations
                </li>
                <li className="rounded-xl border border-white/10 bg-black/20 p-3">
                  Reliable support from sourcing to commissioning
                </li>
              </ul>
            </div>
          </div>

          {/* RIGHT COLUMN - FORM */}
          <div className="lg:col-span-8">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl font-semibold">Send a Message</h2>
                  <p className="mt-1 text-sm text-white/60">
                    Share your requirement and our team will respond as soon as possible.
                  </p>
                </div>
                <span className="rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-white/60">
                  Technical Consultation
                </span>
              </div>

              {successMsg && (
                <div className="mt-4 rounded-xl border border-emerald-400/20 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-200">
                  {successMsg}
                </div>
              )}

              {errorMsg && (
                <div className="mt-4 rounded-xl border border-rose-400/20 bg-rose-400/10 px-4 py-3 text-sm text-rose-200">
                  {errorMsg}
                </div>
              )}

              <form onSubmit={onSubmit} className="mt-6 grid gap-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Field
                    label="Full Name"
                    required
                    value={form.name}
                    onChange={(v) => onChange("name", v)}
                    placeholder="Your full name"
                    error={fieldError("name")}
                  />
                  <Field
                    label="Email Address"
                    required
                    type="email"
                    value={form.email}
                    onChange={(v) => onChange("email", v)}
                    placeholder="you@company.com"
                    error={fieldError("email")}
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <Field
                    label="Company / Organization"
                    value={form.company}
                    onChange={(v) => onChange("company", v)}
                    placeholder="Company name"
                    error={fieldError("company")}
                  />
                  <Field
                    label="Phone Number"
                    value={form.phone}
                    onChange={(v) => onChange("phone", v)}
                    placeholder="01518357567"
                    error={fieldError("phone")}
                  />
                </div>

                <div>
                  <label className="mb-1 block text-sm text-white/80">Service Interest</label>
                  <select
                    value={form.service}
                    onChange={(e) => onChange("service", e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm text-white outline-none focus:border-white/20"
                  >
                    <option value="">Select a service</option>
                    {serviceOptions.map((s) => (
                      <option key={s} value={s} className="bg-zinc-900">
                        {s}
                      </option>
                    ))}
                  </select>
                  {fieldError("service") && (
                    <p className="mt-1 text-xs text-rose-300">{fieldError("service")}</p>
                  )}
                </div>

                <div>
                  <label className="mb-1 block text-sm text-white/80">
                    Project / Requirement Details <span className="text-rose-300">*</span>
                  </label>
                  <textarea
                    value={form.message}
                    onChange={(e) => onChange("message", e.target.value)}
                    rows={7}
                    placeholder="Tell us what you need (equipment type, project scope, issue details, installation requirement, timeline, etc.)"
                    className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm text-white outline-none focus:border-white/20"
                  />
                  {fieldError("message") && (
                    <p className="mt-1 text-xs text-rose-300">{fieldError("message")}</p>
                  )}
                </div>

                <div className="mt-1 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-xs text-white/50">
                    By submitting, you agree to be contacted regarding your inquiry.
                  </p>

                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center justify-center rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-sm font-medium text-white hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {submitting ? "Sending..." : "Send Message"}
                  </button>
                </div>
              </form>
            </div>

            {/* Bottom band */}
            <div className="mt-6 grid gap-4 sm:grid-cols-3">
              <MiniMetric title="Location" value="Dhaka, Bangladesh" />
              <MiniMetric title="Availability" value="Sat–Thu" />
              <MiniMetric title="Support Type" value="On-site + Remote" />
            </div>
          </div>
        </section>


        <section className="mt-8 rounded-3xl border border-white/10 bg-white/5 p-3 md:p-4">
  <div className="mb-3 px-2">
    <h2 className="text-lg font-semibold">Find Us on Map</h2>
    <p className="mt-1 text-sm text-white/60">
      Technical Aid, Mirpur, Dhaka — visit us for project consultation and technical support.
    </p>
  </div>

  <div className="overflow-hidden rounded-2xl border border-white/10">
    <iframe
      title="Technical Aid Location Map"
      src="https://www.google.com/maps?q=House%20No%2064,%20Road%206,%20Block%20A,%20Section%2012,%20Mirpur%201216,%20Dhaka,%20Bangladesh&output=embed"
      width="100%"
      height="360"
      style={{ border: 0 }}
      loading="lazy"
      referrerPolicy="no-referrer-when-downgrade"
    />
  </div>
</section>
      </div>
    </main>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  error,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
  type?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm text-white/80">
        {label} {required && <span className="text-rose-300">*</span>}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm text-white outline-none focus:border-white/20"
      />
      {error && <p className="mt-1 text-xs text-rose-300">{error}</p>}
    </div>
  );
}

function InfoCard({
  label,
  value,
  href,
}: {
  label: string;
  value: string;
  href?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <p className="text-xs text-white/50">{label}</p>
      {href ? (
        <a href={href} className="mt-1 block text-sm text-white/90 hover:text-white">
          {value}
        </a>
      ) : (
        <p className="mt-1 text-sm text-white/90">{value}</p>
      )}
    </div>
  );
}

function MiniMetric({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <p className="text-xs text-white/50">{title}</p>
      <p className="mt-1 text-sm font-medium text-white/90">{value}</p>
    </div>
  );
}