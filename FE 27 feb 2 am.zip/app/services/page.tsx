import ServiceSection from "@/components/services/ServiceSection";
import ServicesIndex from "/components/services/ServicesIndex";

const services = [
  {
    id: "global-sourcing",
    number: "01",
    title: "Global Sourcing",
    intro:
      "Reliable, cost-effective, and timely access to high-quality machinery, equipment, and engineering solutions from international markets.",
    bullets: [
      "Industrial & engineering machinery",
      "Laboratory & research equipment",
      "Electrical, mechanical & automation components",
      "Spare parts and replacement items",
      "Customized and application-specific equipment",
      "Supplier identification & technical evaluation",
      "Negotiation, QA, import coordination & local delivery",
    ],
  },
  {
    id: "supply-installation",
    number: "02",
    title: "Supply & Installation",
    intro:
      "Complete supply, installation, testing, and commissioning for electrical and power systems across Bangladesh.",
    bullets: [
      "Battery charger systems (industrial/substation)",
      "Electrical sub-station equipment",
      "LT/HT panels, PDB, control & protection panels",
      "Transformer installation and associated equipment",
      "MCC, ATS, generator synchronization",
      "Cable laying, termination, earthing & safety compliance",
      "Design, drawings, load calculation, maintenance support",
    ],
  },
  {
    id: "repairing-servicing",
    number: "03",
    title: "Repairing & Servicing",
    intro:
      "Comprehensive repairs, servicing, and preventive maintenance for industrial systems and engineering laboratory instruments.",
    bullets: [
      "Engineering lab equipment (mechanical/electrical/civil/research)",
      "Industrial automation systems",
      "LT/HT panels, PDB, battery charger systems",
      "Substation equipment & protection systems",
      "MCC, transformers, switchgear, motors & drives",
      "Calibration, inspection, thermal checking & performance verification",
      "Fast response to minimize downtime",
    ],
  },
  {
    id: "training",
    number: "04",
    title: "Training",
    intro:
      "Industry-oriented training programs with hands-on kits to bridge academic learning and real-world applications.",
    bullets: [
      "Industrial automation (PLC, VFD, HMI, SCADA, BMS)",
      "Control panel design & instrumentation integration",
      "Power systems (substation ops, relays, panels, drawings)",
      "Embedded systems (Arduino, ESP32, STM32, Raspberry Pi)",
      "IoT system development and data monitoring",
      "Mechanical skills (maintenance, hydraulics, pneumatics)",
      "Customized programs for universities and industries",
    ],
  },
  {
    id: "design-implementation",
    number: "05",
    title: "Design & Implementation",
    intro:
      "End-to-end engineering design and execution—electrical, electronics/PCB, mechanical CAD/CAM, and automation integration.",
    bullets: [
      "Electrical design (SLD, load calc, panel layout, cable sizing)",
      "Earthing & lightning protection design",
      "Electronics/PCB: schematic, layout, prototypes, debugging",
      "Mechanical CAD/CAM, simulation, layouts, plant planning",
      "Manufacturing support: CNC, laser cutting, 3D printing",
      "Automation: PLC control, SCADA, IoT monitoring solutions",
      "Commissioning and production-ready delivery",
    ],
  },
];

export default function ServicesPage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-12">
      <div className="mb-10">
        <p className="text-sm text-white/60">Services</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight md:text-5xl">
          Engineering solutions built for performance.
        </h1>
        <p className="mt-4 max-w-2xl text-white/70">
          Explore our core service lines—designed to reduce risk, improve reliability, and deliver measurable value.
        </p>
      </div>

      <ServicesIndex items={services.map(({ id, title }) => ({ id, title }))} />

      <div className="mt-10 space-y-16">
        {services.map((s) => (
          <ServiceSection key={s.id} {...s} />
        ))}
      </div>

      <div className="mt-16 rounded-3xl border border-white/10 bg-white/5 p-8">
        <h2 className="text-xl font-semibold">Need a custom solution?</h2>
        <p className="mt-2 text-white/70">
          Tell us what you’re building—our team will recommend the most reliable and cost-effective approach.
        </p>
        <a
          href="/contact"
          className="mt-6 inline-flex rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/15"
        >
          Contact us
        </a>
      </div>
    </main>
  );
}