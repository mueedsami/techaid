import { NextResponse } from "next/server";

function getLaravelBaseUrl() {
  return process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";
}

function getAdminKey() {
  return process.env.CONTACT_ADMIN_KEY || "";
}

export async function GET() {
  const adminKey = getAdminKey();
  if (!adminKey) {
    return NextResponse.json(
      { ok: false, message: "CONTACT_ADMIN_KEY is not configured on Next.js server." },
      { status: 500 }
    );
  }

  const baseUrl = getLaravelBaseUrl();
  const target = new URL(`${baseUrl}/api/admin/inquiries-export`);
  target.searchParams.set("key", adminKey);

  return NextResponse.redirect(target.toString(), { status: 302 });
}