import { NextRequest, NextResponse } from "next/server";

function getLaravelBaseUrl() {
  return process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";
}

function getAdminKey() {
  return process.env.CONTACT_ADMIN_KEY || "";
}

async function proxyToLaravel(req: NextRequest, id: string, method: "GET" | "PATCH") {
  const adminKey = getAdminKey();
  if (!adminKey) {
    return NextResponse.json(
      { ok: false, message: "CONTACT_ADMIN_KEY is not configured on Next.js server." },
      { status: 500 }
    );
  }

  const baseUrl = getLaravelBaseUrl();
  const target = `${baseUrl}/api/admin/inquiries/${id}`;

  const res = await fetch(target, {
    method,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      "X-Admin-Key": adminKey,
    },
    body: method === "PATCH" ? JSON.stringify(await req.json()) : undefined,
    cache: "no-store",
  });

  const data = await res.json().catch(() => ({}));
  return NextResponse.json(data, { status: res.status });
}

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    return await proxyToLaravel(req, id, "GET");
  } catch (error: any) {
    return NextResponse.json(
      { ok: false, message: error?.message || "Proxy request failed." },
      { status: 500 }
    );
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    return await proxyToLaravel(req, id, "PATCH");
  } catch (error: any) {
    return NextResponse.json(
      { ok: false, message: error?.message || "Proxy request failed." },
      { status: 500 }
    );
  }
}