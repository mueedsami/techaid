<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        $v = Validator::make($request->all(), [
            'name' => ['required','string','max:120'],
            'email' => ['required','email','max:190'],
            'company' => ['nullable','string','max:190'],
            'phone' => ['nullable','string','max:40'],
            'service' => ['nullable','string','max:120'],
            'message' => ['required','string','max:4000'],
        ]);

        if ($v->fails()) {
            return response()->json(['ok' => false, 'errors' => $v->errors()], 422);
        }

        // For now: return OK. Next step we’ll store in DB + send email.
        return response()->json(['ok' => true, 'message' => 'Received. We will contact you soon.']);
    }
}