import Link from "next/link";
import ClientsGrid from "@/components/sections/ClientsGrid";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import { fetchClients, fetchTestimonials } from "@/lib/api";

export default async function ClientsPage() {
  const [clients, testimonials] = await Promise.all([
    fetchClients(),
    fetchTestimonials({ limit: 6 }),
  ]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 md:py-16">
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6 md:p-10">
        <div className="pointer-events-none absolute right-0 top-0 h-40 w-40 translate-x-10 -translate-y-10 rounded-full border border-white/10 opacity-70" />
        <div className="pointer-events-none absolute bottom-0 left-0 h-24 w-24 -translate-x-8 translate-y-8 rounded-full border border-white/10 opacity-70" />

        <p className="text-sm text-white/60">Our Clients</p>
        <h1 className="mt-2 max-w-4xl text-3xl font-semibold tracking-tight md:text-5xl">
          Trusted by education, industry, and engineering teams across Bangladesh
        </h1>
        <p className="mt-4 max-w-3xl text-white/70">
          Technical Aid supports a diverse range of clients with engineering equipment, technical services, installation, and long-term support.
        </p>

        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            href="/contact"
            className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/15"
          >
            Start a Project
          </Link>
          <Link
            href="/services"
            className="rounded-xl border border-white/10 bg-black/30 px-4 py-2 text-sm font-medium hover:bg-white/10"
          >
            Explore Services
          </Link>
        </div>
      </section>

      <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Client Coverage" value="Education + Industry" />
        <StatCard title="Support Type" value="Supply · Service · Training" />
        <StatCard title="Execution" value="On-site + Technical Support" />
        <StatCard title="Focus" value="Reliability & Value" />
      </section>

      <section className="mt-8">
        <ClientsGrid items={clients} />
      </section>

      <section className="mt-8">
        <TestimonialsSection items={testimonials} />
      </section>

      <section className="mt-8 rounded-3xl border border-white/10 bg-white/5 p-6 md:p-8">
        <h2 className="text-2xl font-semibold tracking-tight">
          Looking for a dependable engineering partner?
        </h2>
        <p className="mt-2 max-w-3xl text-white/70">
          Whether you need sourcing, installation, training, or servicing support, Technical Aid is ready to help with practical and cost-effective solutions.
        </p>

        <div className="mt-5 flex flex-wrap gap-3">
          <Link
            href="/contact"
            className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/15"
          >
            Contact Us
          </Link>
          <Link
            href="/about"
            className="rounded-xl border border-white/10 bg-black/30 px-4 py-2 text-sm font-medium hover:bg-white/10"
          >
            About Technical Aid
          </Link>
        </div>
      </section>
    </main>
  );
}

function StatCard({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <p className="text-xs text-white/50">{title}</p>
      <p className="mt-1 text-sm font-medium text-white/90">{value}</p>
    </div>
  );
}