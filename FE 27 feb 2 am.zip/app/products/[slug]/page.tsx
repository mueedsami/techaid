import Link from "next/link";
import { notFound } from "next/navigation";
import { fetchProductBySlug } from "@/lib/api";

export default async function ProductDetailsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;

  let data;
  try {
    data = await fetchProductBySlug(slug);
  } catch {
    notFound();
  }

  const { product, related } = data;

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 md:py-16">
      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="rounded-3xl border border-white/10 bg-white/5 p-4 md:p-6">
          <div className="aspect-[16/10] overflow-hidden rounded-2xl border border-white/10 bg-black/20">
            {product.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={product.image_url} alt={product.name} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-sm text-white/40">
                Product Image
              </div>
            )}
          </div>

          {product.gallery_images?.length > 0 && (
            <div className="mt-3 grid grid-cols-3 gap-2">
              {product.gallery_images.slice(0, 6).map((img, idx) => (
                <div key={idx} className="aspect-[4/3] overflow-hidden rounded-xl border border-white/10 bg-black/20">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="h-full w-full object-cover" />
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6 md:p-8">
          <p className="text-sm text-white/60">{product.category?.name || "Product"}</p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight md:text-4xl">{product.name}</h1>

          {product.short_title && (
            <p className="mt-2 text-white/70">{product.short_title}</p>
          )}

          <div className="mt-4 flex flex-wrap gap-2">
            {product.sector_tag && (
              <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/80">
                {product.sector_tag}
              </span>
            )}
            {product.is_featured && (
              <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-xs text-emerald-200">
                Featured
              </span>
            )}
          </div>

          <p className="mt-4 text-sm leading-7 text-white/75">
            {product.description || product.summary || "Product details will be updated soon."}
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/contact"
              className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-medium hover:bg-white/15"
            >
              Contact for Inquiry
            </Link>
            <Link
              href="/products"
              className="rounded-xl border border-white/10 bg-black/30 px-4 py-2 text-sm hover:bg-white/10"
            >
              Back to Products
            </Link>
          </div>
        </section>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <section className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-lg font-semibold">Key Features</h2>
          {product.key_features?.length ? (
            <ul className="mt-3 space-y-2">
              {product.key_features.map((f, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-white/75">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-white/60" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-white/60">No feature list added yet.</p>
          )}
        </section>

        <section className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-lg font-semibold">Technical Specs</h2>
          {product.technical_specs?.length ? (
            <div className="mt-3 space-y-2">
              {product.technical_specs.map((s, i) => (
                <div key={i} className="grid grid-cols-[140px_1fr] gap-3 rounded-xl border border-white/10 bg-black/20 px-3 py-2">
                  <p className="text-xs text-white/50">{s.label || "Spec"}</p>
                  <p className="text-sm text-white/80">{s.value || "—"}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="mt-3 text-sm text-white/60">No technical specs added yet.</p>
          )}
        </section>
      </div>

      {related?.length > 0 && (
        <section className="mt-8">
          <h2 className="mb-4 text-xl font-semibold">Related Products</h2>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {related.map((p) => (
              <Link
                key={p.id}
                href={`/products/${p.slug}`}
                className="rounded-2xl border border-white/10 bg-white/5 p-4 hover:border-white/20"
              >
                <p className="text-xs text-white/50">{p.category?.name || "General"}</p>
                <h3 className="mt-1 text-sm font-semibold text-white/90">{p.name}</h3>
                <p className="mt-2 line-clamp-2 text-xs leading-5 text-white/65">{p.summary || "View details"}</p>
              </Link>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}