import Link from "next/link";
import { fetchProductCategories, fetchProducts } from "@/lib/api";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams?: Promise<{ q?: string; category?: string }>;
}) {
  const sp = (await searchParams) || {};
  const q = sp.q?.trim() || "";
  const category = sp.category?.trim() || "";

  const [categories, products] = await Promise.all([
    fetchProductCategories(),
    fetchProducts({ q: q || undefined, category: category || undefined }),
  ]);

  return (
    <main className="mx-auto max-w-7xl px-4 py-12 md:py-16">
      <section className="rounded-3xl border border-white/10 bg-gradient-to-b from-white/10 to-transparent p-6 md:p-10">
        <p className="text-sm text-white/60">Products</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight md:text-5xl">
          Engineering products and technical solutions portfolio
        </h1>
        <p className="mt-4 max-w-3xl text-white/70">
          Explore selected products, training systems, and engineering solution modules delivered by Technical Aid across education and industry sectors.
        </p>
      </section>

      {/* Filter/search toolbar */}
      <section className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4">
        <form className="grid gap-3 md:grid-cols-[1fr_240px_auto]">
          <input
            name="q"
            defaultValue={q}
            placeholder="Search products..."
            className="rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm outline-none focus:border-white/20"
          />

          <select
            name="category"
            defaultValue={category}
            className="rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm outline-none focus:border-white/20"
          >
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.slug}>{c.name}</option>
            ))}
          </select>

          <button
            type="submit"
            className="rounded-xl border border-white/15 bg-white/10 px-4 py-2.5 text-sm font-medium hover:bg-white/15"
          >
            Apply
          </button>
        </form>

        {categories.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            <Link href="/products" className={`rounded-full border px-3 py-1 text-xs ${!category ? "border-white/20 bg-white/10" : "border-white/10 bg-black/30 hover:bg-white/10"}`}>
              All
            </Link>
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/products?category=${encodeURIComponent(c.slug)}`}
                className={`rounded-full border px-3 py-1 text-xs ${
                  category === c.slug ? "border-white/20 bg-white/10" : "border-white/10 bg-black/30 hover:bg-white/10"
                }`}
              >
                {c.name}
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* Grid */}
      <section className="mt-8">
        {products.length === 0 ? (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center">
            <p className="text-white/70">No products found for this filter.</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {products.map((p) => (
              <Link
                key={p.id}
                href={`/products/${p.slug}`}
                className="group rounded-2xl border border-white/10 bg-gradient-to-b from-white/5 to-transparent p-4 transition hover:border-white/20 hover:bg-white/[0.07]"
              >
                <div className="mb-3 aspect-[16/10] overflow-hidden rounded-xl border border-white/10 bg-black/20">
                  {p.image_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={p.image_url}
                      alt={p.name}
                      className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.02]"
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-xs text-white/40">
                      Product Image
                    </div>
                  )}
                </div>

                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-white/50">{p.category?.name || "General"}</p>
                    <h3 className="mt-1 text-base font-semibold leading-5 text-white/95">{p.name}</h3>
                  </div>
                  {p.sector_tag && (
                    <span className="shrink-0 rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] text-white/70">
                      {p.sector_tag}
                    </span>
                  )}
                </div>

                <p className="mt-3 line-clamp-3 text-sm leading-6 text-white/70">
                  {p.summary || "Engineering product and solution module by Technical Aid."}
                </p>

                <div className="mt-4 text-sm text-white/90">
                  View Details <span className="opacity-70">→</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}